import logo from './logo.svg';
import './App.css';
import BasicForm from './component/form/basicForm'
import './component/form/bform.css';


function App() {
  return (
    <div>
      <BasicForm />
    </div>
    
    );
}

export default App;
