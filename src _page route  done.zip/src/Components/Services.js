import React from 'react'
import Navglobal from './Navglobal'

 const Services = () => {
  return (
    <div> Service Page
    </div>
  )
}


export default Services;

