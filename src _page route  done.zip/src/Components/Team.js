 import  Navglobal from './Navglobal'
 import React from 'react'
// import Home from './Home';

  const Team = () => {
  return (
    <div> Team Page
    
    </div>
  )
}

            
export default Team;