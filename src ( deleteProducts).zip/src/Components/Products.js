import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import Jsonfile from '../Components/Jsonfile'

const Products = () => {

    // const [item, setItem] = useState([]);
    const [item, setItem] = useState(Jsonfile);



    // useEffect(() => {
 
    //     FetchProducts()
        
    // },[])

          
        const filterResult = (cartItem) => {
        const result =Jsonfile.filter((currData)=>{
            return currData.category===cartItem;
        }); 
        setItem(result);
        console.log(item);

    }
    


    // const FetchProducts = () => {
    //     axios.get("https://fakestoreapi.com/products")
    //         .then((response) => {

    //             // console.log(response.data);
    //             // console.log(response.data.articles);

   
    //             setItem(response.data);
    //             // console.log(item);

    //             console.log(response);

    //         }


    //         )

    // }



    return (
        <>

            {/* <div className='container my-3'>
                <div className="row">
                    <div className="col-4">
                        <Button onClick={FetchProducts} className="btn btn-primary">FetchProducts</Button>

                    </div>
                </div>
            </div> */}



            <div className="container">

                <div className="btn-group-vertical"> Filter Products
                    <button onClick={()=>filterResult("men's clothing")} type="button" className="btn btn-primary" >Men's wear</button>
                    <button onClick={()=>filterResult("women's clothing")} type="button" className="btn btn-primary">Women's wear</button>
                    <button onClick={()=>filterResult("electronics")} type="button" className="btn btn-primary">Electronics</button>
                    <button onClick={()=>filterResult("jewelery")} type="button" className="btn btn-primary">Jewelery</button>


                </div>




                    <div className="row">

                        {
                            item.map((value) => {
                                // const {image,title,category,description,price}=value
                                return (
                                    <div className="col-md-4 mb-4">
                                        <div className="card" style={{ width: "18rem" }}>
                                            <img className="card-img-top" src={value.image} alt="Card image cap" />
                                            <div className="card-body">
                                                <h5 className="card-title">{value.title}</h5>
                                                <h5 className="card-title">{value.category}</h5>

                                                <p className="card-text">{value.description}</p>

                                                <h2 className="card-title">*{value.rating.rate}</h2>


                                                <h2 className="card-title">${value.price}</h2>
                                                <a href="#" className="btn btn-primary">Buy Now</a>
                                            </div>
                                        </div>
                                    </div>

                                )

                            })
                        }










                    </div>

                </div>


            

        </>
    )
}


export default Products;