import { Navbar } from '../Components/Navbar'
import { Link } from "react-router-dom";

import React from 'react'

  const Team = () => {
  return (
    <div>Team</div>
  )
}

<Link to="/team">Team</Link>
            
export default Team;