import React from 'react'
import { Link } from "react-router-dom";

 const Services = () => {
  return (
    <div>

    <Link to="/services"> </Link>
    </div>
  )
}

{/* <Link to="/services"> </Link> */}

export default Services;