import React, { useState } from 'react';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Registeration from './Components/Registeration';
import Login from './Components/Login';
import Home from './Components/Home';
import LandingPage from './Components/LandingPage';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Team from './Components/Team';
import Services from './Components/Services';
import Navglobal from './Components/Navglobal';
// import Regvalid from './Components/Regvalid';
import NavbarLayout from './Components/NavbarLayout';
import  NotFoundPage  from './Components/NotFoundPage';
import Footer from './Components/Footer';
import ProtectedRoute from './Components/ProtectedRoute';
import Products from './Components/Products';


function App() {
  const [hidelogin,setHidelogin] =useState(" ");
  // const [home,setHome] = Login(true)



  return (
    


    <>

<Router>

      <div className="App">
        
        <Routes>

            <Route element={<NavbarLayout/>}>
            {/* <ProtectedRoute path="/home" element={<Home/>} auth={home}/> */}
            <Route path="/home" element={<ProtectedRoute Cmp={Home} />}></Route>
            {/* <Route path="/home" element={<Home/>} /> */}

            {/* <Route path="/team" element={<ProtectedRoute Comp={Team} />}></Route> */}

             {/* <Route path="/team" element={<ProtectedRoute Tmp ={Team}/>} />
            <Route path="/services" element={<ProtectedRoute Smp ={Services}/>} />

            <Route path="/products" element={<ProtectedRoute Pmp={Products} />}></Route> */}

            {/* <Route path="/products" element={<Products/>} /> */}

                        <Route path="/team" element={<Team/>} />
                        <Route path="/products" element={<Products/>} />
                        <Route path="/Services" element={<Services/>} />




            


          </Route>


          <Route path="/login" element={<Login/>} />
          <Route index element={<LandingPage/>} />
           <Route path="/Register" element={<Registeration/>} />
           <Route path="*" element={<NotFoundPage />}  />


        </Routes>
      </div>

    </Router>


















     
       {/* <Router>
         
        <Navglobal />

        <div className="App">
          <Routes>
            <Route exact path="/" element={<LandingPage/>} />
            <Route path="/team" element={<Team/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/register" element={<Registeration/>} />
            <Route path="/home" element={<Home/>} />


            <Route path="/services" element={<Services/>} />
          </Routes>
        </div>

      </Router> */}
    </>
  );
}
export default App;

  //   <Router>
  //     <div>
  //       <Navglobal />

  //       <Routes>
  //         <Route exact path="/" element={<LandingPage />} />
  //         <Route path="/login" element={<Login />} />
  //         <Route path="/register" element={<Registeration />} />
  //         <Route path="/home" element={<Home />} />
  //         <Route path="/team" element={<Team />} />
  //         <Route path="/services" element={<Services />} />


  //       </Routes>

  //     </div>
  //   </Router>
  // );


