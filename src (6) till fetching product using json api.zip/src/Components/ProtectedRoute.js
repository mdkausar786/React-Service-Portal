import React, { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
// import Login from './Login';
import Home from './Home';
import { render } from "react-dom";
import Team from './Team';

function ProtectedRoute(props){
  let Cmp=props.Cmp
  // let Pmp=props.Pmp
  // let Tmp=props.Tmp
  // let Smp=props.Smp

  const navigate =useNavigate()

  useEffect(()=>{
    if(!localStorage.getItem("userPassword"))
    {
       navigate('./register');
    }

  },[4])

  return (

 <div>

   <Cmp/>
   {/* <Pmp/>
   
   <Smp/>
   <Tmp/> */}
   
 </div>

  )


}


export default ProtectedRoute;
