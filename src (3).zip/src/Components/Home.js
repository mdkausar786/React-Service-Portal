import React,{useState} from "react";
import Login from "./Login";

function Home() {

  const [logout, setLogout] =useState(true);

  function handleClick(){

   setLogout(!logout);
  }

  return (
    <>
      <h1>Welcome</h1>
      <h2>You successfully login</h2>
      <div>
        {/* <button onClick={handleClick} className="forgot-password text-right">
              Logout{" "} </button> */}
      </div>
    </>
  );
}

export default Home;
