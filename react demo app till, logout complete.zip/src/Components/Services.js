import React from 'react'
import Navglobal from './Navglobal'
import services from '../assets/services.jpg'

 const Services = () => {
  return (
    <div>
      {/* <h2  style={{textAlign:"center",backgroundColor:'white'}}>Service Page</h2>  */}
      <img style={{width:'-webkit-fill-available'}} src={services}></img>

    </div>
  )
}


export default Services;

