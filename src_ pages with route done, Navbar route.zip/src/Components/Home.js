import React, { useState } from "react";
import Navglobal from "./Navglobal";
import logo2 from '../assets/logo2.jpg';
import { Link } from "react-router-dom";
import Image from '../assets/home.jpg';
// import '../App.css';



const Home = () => {
  return (
    <div> 
    <h1  style={{textAlign:'center'}}>Home Page</h1>
    <img style={{width:'-webkit-fill-available'}} alt="1000x1000" src={Image} />  

    </div>
  )
}

    
export default Home;



        

        


