 import  Navglobal from './Navglobal'
 import React from 'react'
 import team from '../assets/team.jpg'
 
// import Home from './Home';

  const Team = () => {
  return (
    <div> 
      <h2 style={{textAlign:'center'}}>Team Page</h2>
      <img style={{width:'-webkit-fill-available'}} src={team}></img>

    
    </div>
  )
}

            
export default Team;