import React from 'react'
import { Outlet } from 'react-router-dom';
import Navglobal from './Navglobal';

 const NavbarLayout = () => {
  return (
    <div>
    <Navglobal/>
    <Outlet/>
    </div>
    
  )
}
export default NavbarLayout;
