 import  Navglobal from './Navglobal'
 import React from 'react'
// import Home from './Home';

  const Team = () => {
  return (
    <div> Team Page
    
       {/* <Home /> */}
       <Navglobal/>
    
    </div>
  )
}

            
export default Team;