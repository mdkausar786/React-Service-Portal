import React, { useState } from "react";
import Navglobal from "./Navglobal";
// import Login from "./Login";
import { Form, FormControl, Navbar, NavDropdown, Container,Nav, Button, Figure } from 'react-bootstrap';
import logo2 from '../assets/logo2.jpg';
import { Link } from "react-router-dom";
import Image from '../assets/home.jpg';
// import '../App.css';




function Home() {

  const [logout, setLogout] = useState(true);

  function handleClick() {

    setLogout(!logout);
  }

  return (
    <>
      <div>


        

        <Navbar bg="light" expand="lg" className="Navbar">
          <Container fluid>
            <Navbar.Brand link="#">
              <Figure className="img-responsive">
                <Figure.Image width={100} height={50} alt="100x50" src={logo2} />
              </Figure>

              {/* <img
                alt=""
                src={logo}
                width="30px"
                height="30px"
                className="d-inline-block align-top" /> */}

            </Navbar.Brand>

            <Navbar.Toggle aria-controls="navbarScroll" />

            <Navbar.Collapse id="navbarScroll">
              <Nav
                className="me-auto my-2 my-lg-0"
                style={{ maxHeight: '100px' }}
                navbarScroll
              >

                <Link to="/home" className="nav-item nav-link">Home</Link>

                <Link to="/team" className="nav-item nav-link">Team</Link>
                <Link to="/services" className="nav-item nav-link">Services</Link>

                {/* <Nav.Link href="/team">Team</Nav.Link>
                <Nav.Link href="/services">Services</Nav.Link> */}





                {/* <Nav.Link link="#" disabled>
                  Link
                </Nav.Link> */}

              </Nav>

              <Link to="/">
                <button className="btn btn-primary">Log out</button>
              </Link>

            </Navbar.Collapse>       
             </Container>
        </Navbar>

        {/* <div style={{ src: `url(${Image})` }} >"hello" </div> */}

        <h1 style={{ textAlign: "center" }}>Welcome</h1>

        {/* <Navbar /> */}

        {/* <Figure> */}




      </div>
      <img width={1500} height={1000} alt="1000x1000" src={Image} />






    </>
  );



}

export default Home;

