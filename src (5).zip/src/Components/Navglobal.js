// import {Form,FormControl,Nav,NavDropdown,Container,Button,Figure} from 'react-bootstrap';



import React, { useState } from "react";
// import Login from "./Login";
import { Form, FormControl, NavDropdown,Nav,Navbar,Container, Button, Figure } from 'react-bootstrap';
import logo2 from '../assets/logo2.jpg';
import { Link } from 'react-router-dom';
import Image from '../assets/home.jpg';
import '../App.css';

const Navglobal = () => {

  return (


    <>

       <Navbar bg="light" expand="lg" className="Navbar">
        <Container fluid>
          <Navbar.Brand link="#">
            <Figure className="img-responsive">
              <Figure.Image width={100} height={50} alt="100x50" src={logo2} />
            </Figure>

            
          </Navbar.Brand>

          <Navbar.Toggle aria-controls="navbarScroll" />

          <Navbar.Collapse id="navbarScroll">

            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll >

              <Link to="/home" className="nav-item nav-link">Home</Link>

              <Link to="/team" className="nav-item nav-link">Team</Link>
              <Link to="/services" className="nav-item nav-link">Services</Link>

            </Nav>

            


             <Nav.Link link="#" disabled>
                Link
              </Nav.Link> 


            /* <Link to="/">
              <button className="primary-button">Log out</button>
            </Link>

          </Navbar.Collapse>
        </Container>

      </Navbar> 

       <div style={{ src:`url(${Image})` }} >"hello" </div> 

      <h1 style={{ textAlign: "center" }}>Welcome</h1>

      <Figure>
        <Figure.Image width={1500} height={1000} alt="1000x1000" src={Image} />
      </Figure> 

</>
  );




}
export default Navbar;



