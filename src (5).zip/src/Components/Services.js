import React from 'react'
import Home from './Home';
import Navglobal from './Navglobal'

 const Services = () => {
  return (
    <div> Service
<Navglobal />
{/* <Home/> */}
    </div>
  )
}


export default Services;

